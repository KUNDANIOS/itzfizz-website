import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        fizz: {
          bg:       "#06060a",
          surface:  "#0d0d14",
          gold:     "#c9a84c",
          "gold-lt":"#e8d08a",
          silver:   "#a8b4c0",
          night:    "#0a0f1e",
          road:     "#1a1a22",
          sky1:     "#0d1829",
          sky2:     "#1a2d4a",
          accent:   "#4a9eff",
          warm:     "#ff9248",
        },
      },
    },
  },
  plugins: [],
};

export default config;
