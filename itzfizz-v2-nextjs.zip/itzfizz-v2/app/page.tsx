import HeroSection from "@/components/HeroSection";

export default function Home() {
  return (
    <main className="relative bg-fizz-bg">
      {/* Film grain overlay */}
      <div className="grain" aria-hidden="true" />
      {/* Custom cursors */}
      <div className="cursor-dot"  id="cursor-dot"  aria-hidden="true" />
      <div className="cursor-ring" id="cursor-ring" aria-hidden="true" />
      {/* Hero */}
      <HeroSection />
      {/* After-hero content */}
      <AfterContent />
    </main>
  );
}

function AfterContent() {
  const features = [
    { num:"01", title:"Precision Engineering",    body:"Every component crafted to sub-millimeter tolerance. From intake manifolds to suspension geometry, nothing is left to chance." },
    { num:"02", title:"Aerodynamic Mastery",       body:"Wind tunnel validated at 280km/h. Active aerodynamics that respond in milliseconds, keeping you planted at any speed." },
    { num:"03", title:"Intelligent Drive",         body:"Neural-adaptive chassis systems anticipate road inputs 800 times per second. The car becomes an extension of your instinct." },
    { num:"04", title:"Bespoke Luxury",            body:"Handcrafted interiors selected from 2,400 material combinations. Curated by artisans with decades of heritage." },
  ];
  return (
    <section className="relative z-10 bg-fizz-bg">
      {/* Features */}
      <div className="max-w-[1200px] mx-auto px-[clamp(1.5rem,6vw,5rem)] py-[clamp(5rem,12vh,9rem)]">
        <p className="section-eyebrow font-['Barlow_Condensed'] text-[11px] tracking-[.5em] uppercase text-fizz-gold/50 mb-4 opacity-0">Why ITZFIZZ</p>
        <h2 className="section-h2 font-['Barlow_Condensed'] font-thin tracking-[.08em] leading-[1.05] text-white mb-16 opacity-0"
            style={{ fontSize:"clamp(2.4rem,5vw,5rem)" }}>
          ENGINEERED<br/>FOR THE <strong className="font-bold text-fizz-gold">EXTRAORDINARY</strong>
        </h2>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(280px,1fr))]"
             style={{ gap:"1.5px", background:"rgba(201,168,76,.1)", border:"1px solid rgba(201,168,76,.1)" }}>
          {features.map((f,i) => (
            <div key={i} className="feat-card p-[clamp(2rem,4vw,3rem)] opacity-0">
              <div className="font-['Barlow_Condensed'] font-thin text-[3.5rem] leading-none tracking-[.05em] text-fizz-gold/15 mb-3">{f.num}</div>
              <div className="font-['Barlow_Condensed'] tracking-[.1em] uppercase text-white mb-3"
                   style={{ fontSize:"clamp(1.1rem,2vw,1.5rem)" }}>{f.title}</div>
              <p className="text-[.85rem] leading-[1.7] text-white/35 font-light">{f.body}</p>
            </div>
          ))}
        </div>
      </div>
      {/* CTA */}
      <div className="text-center px-6 py-[clamp(4rem,10vh,8rem)] border-t border-b border-fizz-gold/10 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none"
             style={{ background:"radial-gradient(ellipse 60% 50% at 50% 50%, rgba(201,168,76,.04) 0%, transparent 70%)" }}/>
        <h2 className="cta-h font-['Barlow_Condensed'] font-thin tracking-[.08em] text-white mb-6 opacity-0"
            style={{ fontSize:"clamp(2rem,4.5vw,4.5rem)" }}>READY TO DRIVE<br/>THE FUTURE?</h2>
        <p className="cta-sub text-[.9rem] tracking-[.05em] font-light text-white/30 mb-10 opacity-0">
          Limited production. Exclusive ownership experience.</p>
        <button className="cta-btn opacity-0">Configure Yours</button>
      </div>
      {/* Footer */}
      <footer className="max-w-[1200px] mx-auto px-[clamp(1.5rem,6vw,5rem)] py-10 flex flex-wrap justify-between items-center gap-4 border-t border-white/5">
        <span className="font-['Barlow_Condensed'] font-bold tracking-[.3em] text-xl text-fizz-gold/40">ITZFIZZ</span>
        <span className="text-[10px] tracking-[.3em] uppercase text-white/15">© 2024 ITZFIZZ Automotive</span>
      </footer>
    </section>
  );
}
