"use client";

/**
 * CarSVG.tsx
 *
 * Detailed inline SVG of a low-slung luxury sports car.
 * Rendered in dark metallic with gold trim details.
 *
 * Key animated elements (targeted by GSAP via id):
 *  - #rim-front  — front wheel spokes (rotate on scroll)
 *  - #rim-rear   — rear wheel spokes (rotate on scroll)
 */

export default function CarSVG() {
  return (
    <svg
      viewBox="0 0 640 220"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width:"100%", height:"auto", display:"block", overflow:"visible",
               filter:"drop-shadow(0 20px 60px rgba(10,20,50,.8)) drop-shadow(0 0 25px rgba(201,168,76,.1))" }}
      aria-label="Luxury sports car"
    >
      <defs>
        <linearGradient id="cBody" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%"   stopColor="#2a2a3e"/>
          <stop offset="35%"  stopColor="#1a1a2a"/>
          <stop offset="70%"  stopColor="#12121c"/>
          <stop offset="100%" stopColor="#0a0a12"/>
        </linearGradient>
        <linearGradient id="cRoof" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stopColor="#222232"/>
          <stop offset="100%" stopColor="#0e0e1a"/>
        </linearGradient>
        <linearGradient id="cGlass" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stopColor="rgba(74,158,255,0.35)"/>
          <stop offset="60%"  stopColor="rgba(74,158,255,0.12)"/>
          <stop offset="100%" stopColor="rgba(40,80,140,0.08)"/>
        </linearGradient>
        <linearGradient id="cGold" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%"   stopColor="#a07828"/>
          <stop offset="40%"  stopColor="#e8d08a"/>
          <stop offset="100%" stopColor="#c9a84c"/>
        </linearGradient>
        <linearGradient id="cHighlight" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%"   stopColor="transparent"/>
          <stop offset="30%"  stopColor="rgba(255,255,255,0.06)"/>
          <stop offset="50%"  stopColor="rgba(255,255,255,0.12)"/>
          <stop offset="70%"  stopColor="rgba(255,255,255,0.06)"/>
          <stop offset="100%" stopColor="transparent"/>
        </linearGradient>
        <radialGradient id="cHeadlight" cx="50%" cy="50%">
          <stop offset="0%"   stopColor="rgba(232,208,138,0.95)"/>
          <stop offset="40%"  stopColor="rgba(232,208,138,0.5)"/>
          <stop offset="100%" stopColor="rgba(232,208,138,0.05)"/>
        </radialGradient>
        <radialGradient id="cTail" cx="50%" cy="50%">
          <stop offset="0%"   stopColor="rgba(255,50,50,0.95)"/>
          <stop offset="100%" stopColor="rgba(255,50,50,0.1)"/>
        </radialGradient>
        <radialGradient id="cWheel" cx="50%" cy="50%">
          <stop offset="0%"   stopColor="#2e2e40"/>
          <stop offset="100%" stopColor="#0c0c14"/>
        </radialGradient>
        <filter id="rimGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="1" result="blur"/>
          <feComposite in="SourceGraphic" in2="blur" operator="over"/>
        </filter>
      </defs>

      {/* Ground reflection */}
      <ellipse cx="330" cy="208" rx="230" ry="10" fill="url(#cBody)" opacity="0.2" filter="url(#rimGlow)"/>

      {/* Main body */}
      <path d="M55 170 L75 130 L115 100 L170 72 L250 55 L340 50 L430 54 L495 72 L545 100 L575 130 L590 158 L590 172 Z"
            fill="url(#cBody)" stroke="rgba(255,255,255,0.06)" strokeWidth="0.5"/>

      {/* Sill / lower panel */}
      <path d="M55 170 L590 172 L590 180 L55 180 Z" fill="#0a0a10" stroke="rgba(201,168,76,.12)" strokeWidth="0.5"/>

      {/* Roof */}
      <path d="M185 100 L220 58 L290 35 L370 33 L440 40 L500 65 L530 100 Z"
            fill="url(#cRoof)" stroke="rgba(255,255,255,0.05)" strokeWidth="0.5"/>

      {/* Windshield */}
      <path d="M232 98 L260 52 L348 45 L390 98 Z"
            fill="url(#cGlass)" stroke="rgba(74,158,255,0.3)" strokeWidth="0.8"/>
      {/* Windshield reflection */}
      <path d="M245 96 L268 55 L300 50 L290 96 Z" fill="rgba(255,255,255,0.04)"/>

      {/* Rear window */}
      <path d="M398 98 L432 48 L488 66 L520 98 Z"
            fill="url(#cGlass)" stroke="rgba(74,158,255,0.2)" strokeWidth="0.8"/>

      {/* Door crease lines */}
      <path d="M170 104 Q330 112 530 102" stroke="rgba(255,255,255,0.1)" strokeWidth="1.2" fill="none"/>
      <path d="M170 112 Q330 120 530 110" stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" fill="none"/>

      {/* Body highlight */}
      <path d="M80 155 Q330 145 580 158" stroke="url(#cHighlight)" strokeWidth="18" fill="none" opacity="0.6"/>

      {/* Gold trim strip */}
      <path d="M56 172 L590 173" stroke="url(#cGold)" strokeWidth="1.5" opacity="0.7"/>

      {/* Front fascia */}
      <path d="M58 145 L75 130 L115 102 L100 145 L62 158 Z" fill="url(#cBody)"/>
      {/* Front splitter */}
      <path d="M55 170 L62 178 L100 178 L100 172 Z" fill="url(#cGold)" opacity="0.8"/>

      {/* Rear diffuser */}
      <path d="M590 172 L592 180 L550 180 L550 172 Z" fill="url(#cGold)" opacity="0.7"/>

      {/* Side intake vents */}
      <rect x="108" y="118" width="32" height="5" rx="2.5" fill="rgba(201,168,76,0.35)"/>
      <rect x="108" y="126" width="22" height="3" rx="1.5" fill="rgba(201,168,76,0.2)"/>
      <rect x="108" y="132" width="14" height="2" rx="1"   fill="rgba(201,168,76,0.12)"/>

      {/* Mirror */}
      <path d="M188 90 L200 85 L205 95 L190 100 Z" fill="#1a1a28" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5"/>

      {/* Headlight */}
      <ellipse cx="88" cy="128" rx="20" ry="9" fill="url(#cHeadlight)"/>
      <path d="M68 122 L108 122" stroke="rgba(232,208,138,.7)" strokeWidth="2" strokeLinecap="round"/>
      <ellipse cx="88" cy="128" rx="10" ry="5" fill="rgba(232,208,138,0.95)"/>
      <ellipse cx="88" cy="128" rx="4"  ry="2.5" fill="white"/>

      {/* Taillight */}
      <ellipse cx="572" cy="128" rx="14" ry="7" fill="url(#cTail)"/>
      <path d="M558 122 L586 122" stroke="rgba(255,60,60,.6)" strokeWidth="1.5" strokeLinecap="round"/>
      <ellipse cx="572" cy="128" rx="6" ry="3.5" fill="rgba(255,80,80,.95)"/>

      {/* ── FRONT WHEEL ── */}
      <circle cx="168" cy="186" r="34" fill="url(#cWheel)" stroke="#1a1a24" strokeWidth="1"/>
      <circle cx="168" cy="186" r="34" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="6"/>
      <circle cx="168" cy="186" r="26" fill="#181826" stroke="rgba(201,168,76,.25)" strokeWidth="1"/>
      <circle cx="168" cy="186" r="18" fill="#111118"/>
      <g id="rim-front" style={{ transformOrigin:"168px 186px" }}>
        <g stroke="rgba(201,168,76,.65)" strokeWidth="2.2" strokeLinecap="round">
          <line x1="168" y1="168" x2="168" y2="162"/>
          <line x1="184" y1="170.5" x2="188" y2="165.5"/>
          <line x1="179" y1="199" x2="183.5" y2="204"/>
          <line x1="157" y1="199" x2="152.5" y2="204"/>
          <line x1="152" y1="170.5" x2="148" y2="165.5"/>
        </g>
        <g stroke="rgba(201,168,76,.28)" strokeWidth="1.2">
          <line x1="168" y1="168" x2="184" y2="170.5"/>
          <line x1="184" y1="170.5" x2="179" y2="199"/>
          <line x1="179" y1="199" x2="157" y2="199"/>
          <line x1="157" y1="199" x2="152" y2="170.5"/>
          <line x1="152" y1="170.5" x2="168" y2="168"/>
        </g>
        <circle cx="168" cy="186" r="6" fill="#0e0e18" stroke="rgba(201,168,76,.4)" strokeWidth="1"/>
        <circle cx="168" cy="186" r="3" fill="rgba(201,168,76,.6)"/>
      </g>
      <circle cx="168" cy="186" r="14" fill="none" stroke="rgba(255,255,255,.04)" strokeWidth="2" strokeDasharray="3 3"/>

      {/* ── REAR WHEEL ── */}
      <circle cx="462" cy="186" r="34" fill="url(#cWheel)" stroke="#1a1a24" strokeWidth="1"/>
      <circle cx="462" cy="186" r="34" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="6"/>
      <circle cx="462" cy="186" r="26" fill="#181826" stroke="rgba(201,168,76,.25)" strokeWidth="1"/>
      <circle cx="462" cy="186" r="18" fill="#111118"/>
      <g id="rim-rear" style={{ transformOrigin:"462px 186px" }}>
        <g stroke="rgba(201,168,76,.65)" strokeWidth="2.2" strokeLinecap="round">
          <line x1="462" y1="168" x2="462" y2="162"/>
          <line x1="478" y1="170.5" x2="482" y2="165.5"/>
          <line x1="473" y1="199" x2="477.5" y2="204"/>
          <line x1="451" y1="199" x2="446.5" y2="204"/>
          <line x1="446" y1="170.5" x2="442" y2="165.5"/>
        </g>
        <g stroke="rgba(201,168,76,.28)" strokeWidth="1.2">
          <line x1="462" y1="168" x2="478" y2="170.5"/>
          <line x1="478" y1="170.5" x2="473" y2="199"/>
          <line x1="473" y1="199" x2="451" y2="199"/>
          <line x1="451" y1="199" x2="446" y2="170.5"/>
          <line x1="446" y1="170.5" x2="462" y2="168"/>
        </g>
        <circle cx="462" cy="186" r="6" fill="#0e0e18" stroke="rgba(201,168,76,.4)" strokeWidth="1"/>
        <circle cx="462" cy="186" r="3" fill="rgba(201,168,76,.6)"/>
      </g>
      <circle cx="462" cy="186" r="14" fill="none" stroke="rgba(255,255,255,.04)" strokeWidth="2" strokeDasharray="3 3"/>

      {/* Roof antenna */}
      <line x1="360" y1="33" x2="363" y2="15" stroke="rgba(255,255,255,0.2)" strokeWidth="1"/>
      <circle cx="363" cy="14" r="2" fill="rgba(201,168,76,.6)"/>

    </svg>
  );
}
