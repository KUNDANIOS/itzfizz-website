"use client";

/**
 * HeroSection.tsx
 *
 * Premium scroll-driven hero with:
 *  - Pinned sticky section (ScrollTrigger pin)
 *  - Parallax sky / cloud / mountain / tree / road layers
 *  - Car drives left→right with rotation, scale, and opacity on scroll
 *  - Wheel rim spin synced to scroll progress
 *  - GSAP stagger intro for headline letters
 *  - Animated stat counters
 *  - Custom cursor, film grain, moon twinkle, star field
 */

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import CarSVG    from "./CarSVG";
import ParallaxBg from "./ParallaxBg";

gsap.registerPlugin(ScrollTrigger);

const STATS = [
  { id: "sv0", val: 95, suffix: "%", label: "Customer Satisfaction" },
  { id: "sv1", val: 80, suffix: "%", label: "Performance Boost" },
  { id: "sv2", val: 60, suffix: "%", label: "Efficiency Increase" },
];

export default function HeroSection() {
  const heroRef   = useRef<HTMLElement>(null);
  const stickyRef = useRef<HTMLDivElement>(null);
  const carRef    = useRef<HTMLDivElement>(null);
  const uiRef     = useRef<HTMLDivElement>(null);
  const hintRef   = useRef<HTMLDivElement>(null);

  useEffect(() => {
    /* ── Custom cursor ─────────────────────────────────────────── */
    const dot  = document.getElementById("cursor-dot");
    const ring = document.getElementById("cursor-ring");
    const onMove = (e: MouseEvent) => {
      gsap.to(dot,  { x: e.clientX, y: e.clientY, duration: .1 });
      gsap.to(ring, { x: e.clientX, y: e.clientY, duration: .35, ease: "power2.out" });
    };
    window.addEventListener("mousemove", onMove);

    const ctx = gsap.context(() => {
      /* ══════════════════════════════════════════════════════
         INTRO TIMELINE
      ══════════════════════════════════════════════════════ */
      const intro = gsap.timeline({ defaults: { ease: "power3.out" } });

      intro.fromTo("#top-bar",
        { y: -20, opacity: 0 }, { y: 0, opacity: 1, duration: 1 }, 0);

      intro.fromTo("#eyebrow",
        { y: 16, opacity: 0, letterSpacing: "1em" },
        { y: 0, opacity: 1, letterSpacing: ".55em", duration: 1 }, 0.35);

      /* Stagger each letter */
      intro.fromTo(".hero-letter",
        { y: 80, opacity: 0, skewX: -6 },
        { y: 0, opacity: 1, skewX: 0, duration: .9, stagger: .045, ease: "expo.out" },
        0.5);

      intro.fromTo("#hl-rule",
        { width: 0 }, { width: "40%", duration: 1.2, ease: "expo.out" }, 1.2);

      intro.fromTo("#tagline",
        { y: 14, opacity: 0 }, { y: 0, opacity: 1, duration: .9 }, 1.3);

      /* Stats stagger in */
      intro.fromTo(".stat-item",
        { y: 24, opacity: 0, scale: .95 },
        { y: 0, opacity: 1, scale: 1, duration: .75, stagger: .15, ease: "back.out(1.5)" },
        1.5);

      /* Stat counters */
      STATS.forEach((s, i) => {
        const el = document.getElementById(s.id);
        if (!el) return;
        const obj = { v: 0 };
        gsap.to(obj, {
          v: s.val, duration: 1.6, ease: "power2.out", delay: 1.7 + i * .15,
          onUpdate() { el.textContent = Math.round(obj.v) + s.suffix; },
        });
      });

      /* Car entrance */
      intro.fromTo(carRef.current,
        { x: "-110vw", opacity: 0, rotate: -1.5, scale: .96 },
        { x: "0vw", opacity: 1, rotate: 0, scale: 1, duration: 2, ease: "expo.out" },
        0.8);

      /* Wheel spin on entrance */
      intro.fromTo(["#rim-front", "#rim-rear"],
        { rotate: 0 },
        { rotate: 900, duration: 2, ease: "expo.out" },
        0.8);

      /* Scroll hint */
      intro.fromTo(hintRef.current,
        { y: 10, opacity: 0 }, { y: 0, opacity: 1, duration: 1 },
        2.1);

      /* ── Idle float ──────────────────────────────────────── */
      gsap.to(carRef.current, {
        y: -10, repeat: -1, yoyo: true,
        duration: 2.6, ease: "sine.inOut", delay: 2.9,
      });

      /* ══════════════════════════════════════════════════════
         SCROLL-DRIVEN ANIMATION
         pin: stickyRef pins it at top during the hero scroll travel
      ══════════════════════════════════════════════════════ */
      const scrollTL = gsap.timeline({
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top top",
          end: "bottom top",
          pin: stickyRef.current,
          scrub: 2.2,
          onUpdate(self) {
            const pct = Math.round(self.progress * 100);
            const pr  = document.getElementById("progress-readout");
            if (pr) {
              pr.textContent = pct + "% — SCROLL";
              gsap.to(pr, { opacity: pct > 2 ? 1 : 0, duration: .3 });
            }
          },
        },
      });

      /* Phase 1 – accelerate right */
      scrollTL.to(carRef.current,
        { x: "28vw", rotate: 1.2, scale: 1.05, ease: "power2.inOut", duration: 1 }, 0);

      /* Phase 2 – cruise */
      scrollTL.to(carRef.current,
        { x: "38vw", rotate: .5, scale: 1.08, ease: "power1.inOut", duration: .5 }, 1);

      /* Phase 3 – warp exit */
      scrollTL.to(carRef.current,
        { x: "145vw", rotate: 3, scale: .95, opacity: .4, ease: "power3.in", duration: 1.5 }, 1.5);

      /* Headlight dims at exit */
      scrollTL.fromTo("#headlight-beam",
        { opacity: .4 }, { opacity: .9, duration: 1.5 }, 0);
      scrollTL.to("#headlight-beam", { opacity: 0, duration: .5 }, 1.5);

      /* Speed vignette */
      scrollTL.to("#speed-vignette",
        { opacity: 1, ease: "power2.in", duration: 1.5 }, 1.5);

      /* ── Wheel spin on scroll ───────────────────────────── */
      ScrollTrigger.create({
        trigger: heroRef.current,
        start: "top top", end: "bottom top",
        scrub: 1,
        onUpdate(self) {
          const deg = self.progress * 2160;
          gsap.set("#rim-front", { rotate: deg });
          gsap.set("#rim-rear",  { rotate: deg });
          // Road dash opacity increases with speed illusion
          gsap.set(".road-dash", { opacity: .1 + self.progress * .55 });
        },
      });

      /* ── Parallax layers ────────────────────────────────── */
      gsap.to("#layer-clouds",    { scrollTrigger: { trigger: heroRef.current, start:"top top", end:"bottom top", scrub: 1.8 }, x: "-22%", ease: "none" });
      gsap.to("#layer-mountains", { scrollTrigger: { trigger: heroRef.current, start:"top top", end:"bottom top", scrub: 3   }, x: "-8%",  ease: "none" });
      gsap.to("#layer-trees",     { scrollTrigger: { trigger: heroRef.current, start:"top top", end:"bottom top", scrub: 1.2 }, x: "-35%", ease: "none" });
      gsap.to("#moon",            { scrollTrigger: { trigger: heroRef.current, start:"top top", end:"bottom top", scrub: 2   }, y: "15vh", opacity: .35, scale: .9, ease: "none" });
      gsap.to("#horizon-glow",    { scrollTrigger: { trigger: heroRef.current, start:"top top", end:"bottom top", scrub: 1.5 }, opacity: 2.5, scaleY: 2.5, ease: "power1.inOut" });

      /* ── Hero UI fades out early ────────────────────────── */
      gsap.to(uiRef.current, {
        scrollTrigger: { trigger: heroRef.current, start:"top top", end:"35% top", scrub: 1.2 },
        y: -60, opacity: 0, ease: "none",
      });
      gsap.to(hintRef.current, {
        scrollTrigger: { trigger: heroRef.current, start:"top top", end:"5% top", scrub: 1 },
        opacity: 0, y: -10, ease: "none",
      });

      /* ── After-hero scroll reveals ──────────────────────── */
      [".section-eyebrow", ".section-h2"].forEach(sel => {
        document.querySelectorAll<HTMLElement>(sel).forEach(el => {
          gsap.fromTo(el, { opacity:0, y:28 }, {
            opacity:1, y:0, duration:.9, ease:"power3.out",
            scrollTrigger: { trigger: el, start:"top 84%" },
          });
        });
      });
      document.querySelectorAll<HTMLElement>(".feat-card").forEach((el,i) => {
        gsap.fromTo(el, { opacity:0, y:45 }, {
          opacity:1, y:0, duration:.85, delay: i*.08, ease:"power3.out",
          scrollTrigger: { trigger: el, start:"top 88%" },
        });
      });
      [".cta-h", ".cta-sub", ".cta-btn"].forEach((sel, i) => {
        document.querySelectorAll<HTMLElement>(sel).forEach(el => {
          gsap.fromTo(el, { opacity:0, y:28 }, {
            opacity:1, y:0, duration:.8, delay: i*.12, ease:"power3.out",
            scrollTrigger: { trigger: el, start:"top 86%" },
          });
        });
      });

    }, heroRef);

    return () => {
      ctx.revert();
      window.removeEventListener("mousemove", onMove);
    };
  }, []);

  return (
    /* Tall section gives scroll room */
    <section ref={heroRef} className="relative" style={{ height: "500vh" }}>

      {/* Sticky viewport container */}
      <div ref={stickyRef} className="sticky top-0 h-screen w-full overflow-hidden">

        {/* ── Parallax background layers ─────────────────── */}
        <ParallaxBg />

        {/* ── Car ────────────────────────────────────────── */}
        <div
          id="car-container"
          className="absolute z-[25] pointer-events-none"
          style={{ bottom: "27%", left: 0, right: 0, height: "240px" }}
        >
          <div
            ref={carRef}
            style={{
              position: "absolute", bottom: 0,
              left: "50%", transform: "translateX(-50%) translateX(-115vw)",
              width: "min(640px, 70vw)",
              transformOrigin: "center bottom",
              opacity: 0,
              willChange: "transform, opacity",
            }}
          >
            {/* Headlight beam */}
            <div
              id="headlight-beam"
              style={{
                position: "absolute", left: "0%", bottom: "22%",
                width: "220px", height: "120px",
                background: "conic-gradient(from -20deg at 100% 60%, transparent 0deg, rgba(232,208,138,.18) 20deg, rgba(232,208,138,.06) 35deg, transparent 45deg)",
                transformOrigin: "right center",
                filter: "blur(4px)", opacity: .4,
                willChange: "opacity",
              }}
            />
            {/* Tail glow */}
            <div
              id="tail-glow"
              className="tail-pulse"
              style={{
                position: "absolute", right: "2%", bottom: "22%",
                width: "60px", height: "30px",
                background: "radial-gradient(ellipse, rgba(255,60,60,.6) 0%, transparent 70%)",
                filter: "blur(3px)",
              }}
            />
            {/* Ground shadow */}
            <div style={{
              position: "absolute", bottom: "-8px", left: "50%",
              transform: "translateX(-50%)",
              width: "85%", height: "24px",
              background: "radial-gradient(ellipse, rgba(0,0,0,.7) 0%, transparent 70%)",
              filter: "blur(6px)",
            }} />
            {/* Car SVG */}
            <CarSVG />
          </div>
        </div>

        {/* Speed vignette overlay */}
        <div
          id="speed-vignette"
          className="absolute inset-0 pointer-events-none z-[28]"
          style={{
            opacity: 0, willChange: "opacity",
            background: "radial-gradient(ellipse 50% 50% at 50% 50%, transparent 30%, rgba(0,0,0,.5) 100%)",
          }}
          aria-hidden="true"
        />

        {/* ── Hero UI text ────────────────────────────────── */}
        <div ref={uiRef} className="absolute inset-x-0 top-0 z-30 flex flex-col items-center">
          <div
            id="top-bar"
            className="w-full flex justify-between items-center opacity-0 mt-7"
            style={{ padding: "0 clamp(1.5rem,5vw,4rem)" }}
          >
            {["[ITZFIZZ / 2024]", "Drive The Future", "Vol. I"].map((t, i) => (
              <span key={i} className="font-['Barlow_Condensed'] text-[11px] font-light tracking-[.35em] uppercase text-fizz-gold/55">
                {t}
              </span>
            ))}
          </div>

          <div id="eyebrow" className="font-['Barlow_Condensed'] font-light tracking-[.55em] uppercase text-fizz-gold/60 mt-10 opacity-0"
               style={{ fontSize:"clamp(10px,1.2vw,13px)" }}>
            The Future of Luxury Mobility
          </div>

          {/* Headline */}
          <div className="flex flex-wrap justify-center items-baseline gap-x-3 mt-4 px-4 text-center"
               aria-label="Welcome ITZFIZZ">
            <div className="flex">
              {"WELCOME".split("").map((ch,i) => (
                <span key={i} className="hero-letter">{ch}</span>
              ))}
            </div>
            <div className="flex">
              {"ITZFIZZ".split("").map((ch,i) => (
                <span key={i} className="hero-letter brand">{ch}</span>
              ))}
            </div>
          </div>

          {/* Rule */}
          <div id="hl-rule" className="h-px mt-5 mb-5"
               style={{ background:"linear-gradient(90deg,transparent,rgba(201,168,76,.5),transparent)", width:"0" }} />

          {/* Tagline */}
          <div id="tagline" className="font-['Cormorant_Garamond'] font-light italic text-white/40 tracking-[.08em] opacity-0 mb-8"
               style={{ fontSize:"clamp(.9rem,1.8vw,1.4rem)" }}>
            Where precision meets the asphalt
          </div>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-x-10 gap-y-4">
            {STATS.map((s, i) => (
              <>
                <div key={s.id} className="stat-item flex flex-col items-center gap-1 opacity-0">
                  <div id={s.id} className="font-['Barlow_Condensed'] font-bold leading-none tracking-[.04em] text-fizz-gold"
                       style={{ fontSize:"clamp(1.6rem,3.5vw,2.8rem)", textShadow:"0 0 20px rgba(201,168,76,.5),0 0 60px rgba(201,168,76,.2)" }}>
                    0{s.suffix}
                  </div>
                  <div className="font-['Barlow_Condensed'] font-light tracking-[.3em] uppercase text-white/30"
                       style={{ fontSize:"clamp(9px,1.1vw,11px)" }}>
                    {s.label}
                  </div>
                </div>
                {i < STATS.length - 1 && (
                  <div key={`sep-${i}`} className="w-px self-center opacity-0 stat-item"
                       style={{ height:"40px", background:"linear-gradient(to bottom,transparent,rgba(201,168,76,.35),transparent)" }} />
                )}
              </>
            ))}
          </div>
        </div>

        {/* Scroll hint */}
        <div ref={hintRef}
             className="absolute bottom-8 left-1/2 -translate-x-1/2 z-40 flex flex-col items-center gap-2 opacity-0"
             aria-label="Scroll to explore">
          <span className="font-['Barlow_Condensed'] text-[10px] tracking-[.4em] uppercase text-fizz-gold/50">
            Scroll to Explore
          </span>
          <div className="w-px h-10 scroll-line-anim"
               style={{ background:"linear-gradient(to bottom,rgba(201,168,76,.5),transparent)" }} />
        </div>

        {/* Progress readout */}
        <div id="progress-readout"
             className="fixed bottom-8 left-8 z-50 font-['Barlow_Condensed'] text-[10px] tracking-[.3em] text-fizz-gold/40"
             style={{ opacity: 0 }} />

      </div>
    </section>
  );
}
