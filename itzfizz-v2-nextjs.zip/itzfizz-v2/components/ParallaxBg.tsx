"use client";

/**
 * ParallaxBg.tsx
 *
 * All background scene layers rendered as pure SVG / CSS.
 * Each layer is given an id for GSAP to target individually
 * with different parallax scrub speeds.
 *
 * Layers (back to front):
 *  1. #layer-sky       — gradient sky + moon + stars + city glow
 *  2. #layer-mountains — distant mountain silhouettes (slowest parallax)
 *  3. #layer-clouds    — cloud shapes (medium parallax)
 *  4. #layer-trees     — pine tree silhouettes (fastest parallax)
 *  5. #layer-road      — road surface with dashes + edge lines
 */

import { useEffect } from "react";
import gsap from "gsap";

export default function ParallaxBg() {
  useEffect(() => {
    /* ── Star twinkle (CSS-independent GSAP loop) ──────────── */
    document.querySelectorAll<HTMLElement>(".star-dot").forEach(s => {
      gsap.to(s, {
        opacity: () => Math.random() * .2 + .05,
        duration: () => Math.random() * 3 + 1.5,
        repeat: -1, yoyo: true, ease: "sine.inOut",
        delay: () => Math.random() * 4,
      });
    });
  }, []);

  /* Generate star positions deterministically for SSR safety */
  const stars = Array.from({ length: 140 }, (_, i) => ({
    x: ((i * 137.508) % 100).toFixed(2),
    y: ((i * 97.3)    % 62 ).toFixed(2),
    r: (0.4 + (i % 5) * 0.38).toFixed(1),
    op: (0.15 + (i % 7) * 0.11).toFixed(2),
  }));

  /* Road dashes — perspective scale, closer at bottom */
  const dashes = Array.from({ length: 10 }, (_, i) => ({
    h:   4 + (i / 9) * 26,
    bot: 8 + i * 9,
    op:  0.1 + (i / 9) * 0.4,
  }));

  return (
    <>
      {/* ── SKY ─────────────────────────────────────────── */}
      <div id="layer-sky" className="absolute inset-0 overflow-hidden">

        {/* Sky gradient */}
        <div className="absolute inset-0" style={{
          background: `
            radial-gradient(ellipse 80% 40% at 50% 100%, #1a3050 0%, transparent 70%),
            linear-gradient(to bottom, #04080f 0%, #0b1628 55%, #1a3050 100%)
          `,
        }} />

        {/* Moon */}
        <div id="moon" style={{
          position: "absolute", width: 54, height: 54,
          top: "8%", right: "15%", borderRadius: "50%",
          background: "radial-gradient(circle at 35% 35%, #e8e0cc, #b8a870)",
          boxShadow: "0 0 0 1px rgba(232,208,138,.15), 0 0 30px rgba(201,168,76,.25), 0 0 80px rgba(201,168,76,.1)",
          willChange: "transform, opacity",
        }}>
          {/* Craters */}
          <div style={{
            position: "absolute", inset: 0, borderRadius: "50%",
            background: `
              radial-gradient(circle 6px at 40% 30%, rgba(0,0,0,.2) 0%, transparent 100%),
              radial-gradient(circle 3px at 65% 55%, rgba(0,0,0,.15) 0%, transparent 100%),
              radial-gradient(circle 4px at 25% 65%, rgba(0,0,0,.18) 0%, transparent 100%)
            `,
          }} />
        </div>

        {/* City horizon glow */}
        <div id="city-glow" style={{
          position: "absolute", bottom: "38%", left: "50%",
          transform: "translateX(-50%)",
          width: "70vw", height: 120,
          background: "radial-gradient(ellipse 60% 100% at 50% 100%, rgba(74,158,255,.12) 0%, rgba(74,158,255,.05) 40%, transparent 70%)",
        }} />

        {/* Warm horizon glow */}
        <div id="horizon-glow" style={{
          position: "absolute", bottom: "36%", left: 0, right: 0, height: 80,
          background: "linear-gradient(to top, rgba(255,146,72,.08) 0%, rgba(201,168,76,.05) 30%, transparent 100%)",
          willChange: "transform, opacity",
        }} />

        {/* Stars */}
        <svg viewBox="0 0 100 100" preserveAspectRatio="none"
             style={{ position:"absolute", inset:0, width:"100%", height:"100%", pointerEvents:"none" }}
             aria-hidden="true">
          {stars.map((s,i) => (
            <circle key={i} className="star-dot"
              cx={s.x} cy={s.y} r={s.r}
              fill="white" opacity={s.op} />
          ))}
        </svg>

      </div>

      {/* ── MOUNTAINS ──────────────────────────────────── */}
      <div id="layer-mountains"
           className="absolute"
           style={{ bottom: "36%", left: "-5%", right: "-5%", height: 200, willChange: "transform" }}>
        <svg viewBox="0 0 1440 200" preserveAspectRatio="none"
             style={{ width:"100%", height:"100%", display:"block" }} aria-hidden="true">
          {/* Distant range */}
          <path d="M0,200 L0,140 L80,90 L180,130 L280,70 L390,120 L500,60 L620,110 L740,50 L860,100 L980,40 L1100,95 L1220,45 L1350,90 L1440,55 L1440,200 Z"
                fill="rgba(18,28,48,0.9)"/>
          {/* Closer range */}
          <path d="M0,200 L0,160 L120,115 L240,150 L360,100 L480,140 L600,85 L720,130 L850,80 L970,125 L1090,70 L1210,115 L1340,85 L1440,110 L1440,200 Z"
                fill="rgba(12,18,32,0.95)"/>
          {/* Gold ridge highlight */}
          <path d="M0,168 L120,122 L240,158 L360,108 L480,148 L600,93 L720,138 L850,88 L970,133 L1090,78 L1210,123 L1340,93 L1440,118"
                fill="none" stroke="rgba(201,168,76,0.06)" strokeWidth="1"/>
        </svg>
      </div>

      {/* ── CLOUDS ─────────────────────────────────────── */}
      <div id="layer-clouds"
           className="absolute pointer-events-none"
           style={{ top:"4%", left:"-5%", right:"-5%", height:"32%", willChange:"transform" }}>
        <svg viewBox="0 0 1440 200" preserveAspectRatio="xMidYMid meet"
             style={{ width:"100%", height:"100%", display:"block" }} aria-hidden="true">
          <defs>
            <radialGradient id="cg0" cx="50%" cy="80%">
              <stop offset="0%" stopColor="rgba(30,55,90,0.7)"/>
              <stop offset="100%" stopColor="rgba(15,28,50,0.2)"/>
            </radialGradient>
          </defs>
          {/* Cloud 1 */}
          <g opacity=".6">
            <ellipse cx="120" cy="120" rx="80" ry="40" fill="url(#cg0)"/>
            <ellipse cx="170" cy="95"  rx="55" ry="38" fill="url(#cg0)"/>
            <ellipse cx="220" cy="110" rx="45" ry="30" fill="url(#cg0)"/>
          </g>
          {/* Cloud 2 */}
          <g opacity=".45" transform="translate(320,-15)">
            <ellipse cx="100" cy="110" rx="70" ry="35" fill="url(#cg0)"/>
            <ellipse cx="145" cy="88"  rx="50" ry="32" fill="url(#cg0)"/>
            <ellipse cx="190" cy="105" rx="40" ry="26" fill="url(#cg0)"/>
          </g>
          {/* Cloud 3 */}
          <g opacity=".5" transform="translate(640, 10)">
            <ellipse cx="130" cy="130" rx="90" ry="45" fill="url(#cg0)"/>
            <ellipse cx="190" cy="100" rx="65" ry="40" fill="url(#cg0)"/>
            <ellipse cx="250" cy="118" rx="50" ry="32" fill="url(#cg0)"/>
          </g>
          {/* Cloud 4 */}
          <g opacity=".4" transform="translate(980,-5)">
            <ellipse cx="110" cy="115" rx="75" ry="38" fill="url(#cg0)"/>
            <ellipse cx="158" cy="92"  rx="55" ry="34" fill="url(#cg0)"/>
            <ellipse cx="205" cy="108" rx="42" ry="28" fill="url(#cg0)"/>
          </g>
        </svg>
      </div>

      {/* ── TREES ──────────────────────────────────────── */}
      <div id="layer-trees"
           className="absolute pointer-events-none"
           style={{ bottom:"35%", left:"-5%", right:"-5%", height:180, willChange:"transform" }}>
        <svg viewBox="0 0 1440 180" preserveAspectRatio="none"
             style={{ width:"100%", height:"100%", display:"block" }} aria-hidden="true">
          <g fill="rgba(6,8,14,1)">
            {/* Left tree cluster */}
            <rect x="10"  y="40"  width="10" height="140"/>
            <polygon points="15,40  -5,100  35,100"/>
            <polygon points="15,10  -10,70  40,70"/>
            <rect x="50"  y="60"  width="8"  height="120"/>
            <polygon points="54,60  34,110  74,110"/>
            <polygon points="54,30  30,80   78,80"/>
            <rect x="90"  y="50"  width="10" height="130"/>
            <polygon points="95,50  70,100  120,100"/>
            <polygon points="95,18  67,75   123,75"/>
            <rect x="130" y="70"  width="7"  height="110"/>
            <polygon points="133,70 115,115 151,115"/>
            <rect x="165" y="45"  width="9"  height="135"/>
            <polygon points="169,45 148,95  190,95"/>
            <polygon points="169,15 145,70  193,70"/>
            {/* Right tree cluster */}
            <g opacity="0.6">
              <rect x="1280" y="55"  width="9"  height="125"/>
              <polygon points="1284,55 1264,105 1304,105"/>
              <polygon points="1284,22 1261,78  1307,78"/>
              <rect x="1320" y="70"  width="8"  height="110"/>
              <polygon points="1324,70 1305,115 1343,115"/>
              <rect x="1360" y="48"  width="10" height="132"/>
              <polygon points="1365,48 1343,98  1387,98"/>
              <polygon points="1365,16 1340,72  1390,72"/>
              <rect x="1400" y="65"  width="8"  height="115"/>
              <polygon points="1404,65 1384,112 1424,112"/>
            </g>
          </g>
        </svg>
      </div>

      {/* ── ROAD ───────────────────────────────────────── */}
      <div id="layer-road"
           className="absolute"
           style={{ bottom:0, left:0, right:0, height:"38%", willChange:"transform" }}>

        {/* Asphalt */}
        <div style={{
          position:"absolute", inset:0, left:"-10%", right:"-10%",
          background:"linear-gradient(to bottom, rgba(17,17,24,0) 0%, #111118 25%, #0e0e16 100%)",
        }}/>

        {/* Road edge lines (perspective) */}
        <div style={{
          position:"absolute", bottom:0, left:"15%", top:0, width:3,
          background:"linear-gradient(to bottom, transparent, rgba(201,168,76,.5), #c9a84c)",
          transformOrigin:"bottom center",
          transform:"perspective(400px) rotateX(12deg) skewX(28deg)",
        }}/>
        <div style={{
          position:"absolute", bottom:0, right:"15%", top:0, width:3,
          background:"linear-gradient(to bottom, transparent, rgba(201,168,76,.5), #c9a84c)",
          transformOrigin:"bottom center",
          transform:"perspective(400px) rotateX(12deg) skewX(-28deg)",
        }}/>

        {/* Center dashes */}
        {dashes.map((d,i) => (
          <div key={i} className="road-dash" style={{
            position:"absolute", left:"50%", transform:"translateX(-50%)",
            width:3, height:d.h,
            bottom:`${d.bot}%`, opacity:d.op,
            background:"rgba(201,168,76,.45)",
            willChange:"opacity",
          }}/>
        ))}

        {/* Road sheen */}
        <div style={{
          position:"absolute", inset:0,
          background:"radial-gradient(ellipse 40% 30% at 50% 80%, rgba(74,158,255,.06) 0%, transparent 70%)",
        }}/>
      </div>
    </>
  );
}
